<div id="browselist" class="clearfix">
<h3 class="sidetitle"> Browse Listing</h3>
<p class="listin"><span>Location</span><br/><?php the_dropdown_taxonomy('location'); ?></p>
<p class="listir"><span>Property type</span><br/><?php the_dropdown_taxonomy('property'); ?></p>
<p class="listin"><span>Square feet Area</span><br/><?php the_dropdown_taxonomy('area'); ?></p>
<p class="listir"><span>Bedrooms</span><br/><?php the_dropdown_taxonomy('bedrooms'); ?></p>
<p class="listin"><span>Type of listing</span><br/><?php the_dropdown_taxonomy('type'); ?></p>
<p class="listir"><span>Price range</span><br/><?php the_dropdown_taxonomy('range'); ?></p>
</div>